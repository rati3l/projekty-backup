import num

print(num.kwadrat(10))

